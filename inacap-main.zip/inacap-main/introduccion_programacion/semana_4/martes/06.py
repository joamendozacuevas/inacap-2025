correo_electronico = "francisca@correo.cl"
longitud_correo = len(correo_electronico)
print("La longitud del correo electrónico es:", longitud_correo)