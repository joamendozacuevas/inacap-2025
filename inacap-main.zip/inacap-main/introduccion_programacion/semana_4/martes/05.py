nombre_completo = "Francisca Tapia"
saludo = "Hola, " + nombre_completo + "."
print(saludo)