edad_menor = 25
edad_mayor = 40
es_mayor = edad_mayor > edad_menor
print(es_mayor)
