# primer cuadrante
coordenada_x = 3.5
coordenada_y = 2.0
distancia_al_origen = (coordenada_x ** 2 + coordenada_y ** 2) ** 0.5
print("La distancia al origen es:", distancia_al_origen)
print("---------------------------------------------------------------------")
# origen
coordenada_x = 0
coordenada_y = 0
distancia_al_origen = (coordenada_x ** 2 + coordenada_y ** 2) ** 0.5
print("La distancia al origen es:", distancia_al_origen)
print("---------------------------------------------------------------------")
# segundo cuadrante
coordenada_x = 3.5
coordenada_y = -2.0
distancia_al_origen = (coordenada_x ** 2 + coordenada_y ** 2) ** 0.5
print("La distancia al origen es:", distancia_al_origen)
print("---------------------------------------------------------------------")
# tercer cuadrante
coordenada_x = -3.5
coordenada_y = -2.0
distancia_al_origen = (coordenada_x ** 2 + coordenada_y ** 2) ** 0.5
print("La distancia al origen es:", distancia_al_origen)
print("---------------------------------------------------------------------")
# cuarto cuadrante
coordenada_x = -3.5
coordenada_y = 2.0
distancia_al_origen = (coordenada_x ** 2 + coordenada_y ** 2) ** 0.5
print("La distancia al origen es:", distancia_al_origen)