cantidad_productos = 150
productos_vendidos = 30
productos_restantes = cantidad_productos - productos_vendidos
print("La cantidad de productos restantes es:", productos_restantes)
print(f"La cantidad de productos restantes es: { productos_restantes }")