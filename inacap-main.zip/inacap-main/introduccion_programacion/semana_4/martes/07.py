tarea_completada = True
tarea_pendiente = not tarea_completada
print(tarea_completada)
print(tarea_pendiente)  