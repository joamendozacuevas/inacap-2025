Tipos de datos en Python

Enteros (int)
Flotantes (float)
Cadenas de Texto (str)
Booleanos (bool)