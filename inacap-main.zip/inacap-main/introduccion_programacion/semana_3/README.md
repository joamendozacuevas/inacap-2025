Semana 3

    identación
    comentarios
    funciòn print
    El separador (sep=’ ‘)
    El caracter final (end=’\n’)

    Estructuras de decisión
        La estructura if
        La Estructura if - else:
        La estructura if – elif – else

    Los Bucles

        El bucle for
        El bucle while
        El control de bucles
        Instrucción continue
        Instrucción else

<b>No se podrá  Ingresar notas por el siguiente  motivo :</b></br> Nota insertada hace más de 48hrs.</br>

Semana 4

Semana 5

Semana 6

Semana 7

Semana 8

Semana 9









