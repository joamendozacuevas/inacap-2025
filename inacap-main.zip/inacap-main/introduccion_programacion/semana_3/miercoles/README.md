Usted ha sido contratado para prestar servicios en el casino de la sede de INACAP Ñuñoa.
La primera labor encomendada, es que realice la gestión de productos del casino.
Utilice sus conocimientos en Python para cumplir los siguientes requerimientos:

- Ejemplos de if, if-else, if-elif-else relacionados con el contexto anterior
- Ejemplos del bucle for sin el uso de estructuras de datos.
- Ejemplos del bucle while sin el uso de estructuras de datos.
- Utilizar control de bucles con break, continue, else.