# Ejemplo de bucle for sin estructuras de datos
print("--- Revisando stock de productos ---")
numero_productos = int(input(f"Ingrese número de productos para revisión de stock: "))

for i in range(numero_productos):
    print(f"Verificación número {i + 1} realizada.")
    #agregar un if por producto