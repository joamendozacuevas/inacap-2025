contador = 0
while contador < 10:
    print(contador)
    contador += 1
    # contador = contador + 1
