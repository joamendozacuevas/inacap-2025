# Esto es un comentario de una sola línea
def saludar(nombre):
    print(type(nombre))
    """
    Esta función imprime un saludo personalizado.
    Este es un comentario multilinea
    """
    print("Hola,", nombre, "!")  # Imprime un saludo con el nombre

saludar(5.5)