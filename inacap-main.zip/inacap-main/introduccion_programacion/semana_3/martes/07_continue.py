for numero in range(10):
    if numero % 2 == 0:
        continue  # Salta los números pares
    print(numero)