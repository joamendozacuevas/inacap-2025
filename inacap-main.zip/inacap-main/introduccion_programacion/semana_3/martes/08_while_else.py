contador = 0
while contador < 5:
    print(contador)
    contador += 1
else:
    print("El bucle ha terminado.")