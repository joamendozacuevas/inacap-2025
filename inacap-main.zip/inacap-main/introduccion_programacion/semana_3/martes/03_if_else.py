edad = 18
if edad >= 18:
    print("Eres mayor de edad, porque tu edad es ", edad, ".")