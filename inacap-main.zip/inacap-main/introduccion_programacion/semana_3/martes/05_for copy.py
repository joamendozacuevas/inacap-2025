# Arreglo con los meses del año
meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", 
         "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

print(len(meses))
print(len(meses[0]))

# Bucle para imprimir cada mes
for mes in meses:
    print(mes)
    print(mes[1])
    # print(meses[0])
