calificacion = 55
if calificacion > 100:
    print("Excede límite de calificacion, ingresar hasta 100.")
elif calificacion >= 90:
    print("Excelente, calificacion", calificacion)
elif calificacion >= 80:
    print("Bueno, calificacion", calificacion)
elif calificacion >= 70:
    print("Regular, calificacion", calificacion)
else:
    print("Necesitas mejorar, calificacion", calificacion)